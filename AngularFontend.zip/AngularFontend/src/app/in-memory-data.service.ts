import { InMemoryDbService } from 'angular-in-memory-web-api';

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const employees = [
        { employId: '11', employFName: '11', employLName: 'Mr. Nice',gendar:'M',mobileNumber:'9876545450',emailId:'Srinu@gmail.com',role:'GL',password:'SRINU' },
   
        {  employId: '11',employFName: '12', employLName: 'Mr. Nice',gendar:'M',mobileNumber:'9876545450',emailId:'Srinu@gmail.com',role:'GL',password:'SRINU' },
        {  employId: '11', employFName: '13', employLName: 'Mr. Nice',gendar:'M',mobileNumber:'9876545450',emailId:'Srinu@gmail.com',role:'GL',password:'SRINU' },
        {  employId: '11',employFName: '14', employLName: 'Mr. Nice',gendar:'M',mobileNumber:'9876545450',emailId:'Srinu@gmail.com',role:'GL',password:'SRINU' },
        {  employId: '11',employFName: '15', employLName: 'Mr. Nice',gendar:'M',mobileNumber:'9876545450',emailId:'Srinu@gmail.com',role:'GL',password:'SRINU' },
        {  employId: '11',employFName: '16', employLName: 'Mr. Nice',gendar:'M',mobileNumber:'9876545450',emailId:'Srinu@gmail.com',role:'GL',password:'SRINU' }
       
    ];
    return {employees};
  }
}


    
