export class Employee {
    
    employId :number;
    employFName: string;
    employLName: string;
    gendar: string;
    mobileNumber: string;
    emailId: string;
    role: string;
    password: string;
   
    
  }